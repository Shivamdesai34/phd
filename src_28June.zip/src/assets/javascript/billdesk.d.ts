// import { FillprofileComponent } from './../../app/views/students/fillprofile/fillprofile.component';

export declare function BilldeskPay(data :any,myurl : string, modulename: string) : any;
