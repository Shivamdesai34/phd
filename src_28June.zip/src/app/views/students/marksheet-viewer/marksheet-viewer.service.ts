import {Injectable} from '@angular/core';
import {HttpClient,} from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class MarksheetViewerService {
  constructor(private http: HttpClient) {}


  // Error handling

}
