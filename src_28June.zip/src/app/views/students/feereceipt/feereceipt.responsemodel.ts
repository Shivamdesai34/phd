import {Golbal_CollegeCode} from "../../../globals/global-variable";



export class Ifinyear{
  "Finyear": number
}

export class IBatchname{
  "Finyear": number
  "Batch_code": number
  "Batch_name": string
  "Installment": number
}
