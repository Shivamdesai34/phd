import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-successresponse',
  templateUrl: './successresponse.component.html',
  styleUrls: ['./successresponse.component.scss']
})
export class SuccessresponseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
