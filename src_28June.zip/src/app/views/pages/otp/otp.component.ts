import {Global_LastFinYear, Golbal_CollegeCode,} from '../../../globals/global-variable';
import {Component, OnInit} from '@angular/core';
import {UntypedFormBuilder, UntypedFormGroup, Validators,} from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import {OtpService} from './otp.service';
import {GlobalMessage} from "../../../globals/global.message";

@Component({
    selector: 'app-otp',
    templateUrl: './otp.component.html',
    styleUrls: ['./otp.component.scss'],
})
export class OtpComponent implements OnInit {
    CollegeCodeConst = Golbal_CollegeCode;
    FinYearConst = Global_LastFinYear;

    otpVerifyForm!: UntypedFormGroup;
    submitted = false;
    data: any;

    Aadhaar: any;
    EmailID: any;
    MobileNumber: any;
    registerresponse: any;
    flag: any;
    otp: any;

    // @Input() public OTPGetValue;
    // public OTPSendValue;
    get f() {
        return this.otpVerifyForm.controls;
    }

    constructor(
        private router: Router,private globalmessage: GlobalMessage,
        private formBuilder: UntypedFormBuilder,
        private otpService: OtpService,
        private activatedRoute: ActivatedRoute,
    ) {
    }

    ngOnInit(): void {
        // this.otpService.valuefromService(value => value);
        // this.registerresponse = this.otpService.otpResponse;
        // this.Aadhaar = this.registerresponse.Aadhaar

        // if (this.Aadhaar == "" || this.Aadhaar == undefined) {
        //   this.router.navigate(['register'])
        // }
        // else {
        //   this.RegisterResponse()
        // }

        // this.activatedRoute.queryParams.subscribe(params => {
        //   this.flag = params['flag'];
        //   this.EmailID = params['EmailID'];
        //   this.MobileNumber = params['MobileNumber'];
        //   console.log(this.Aadhaar,this.EmailID,this.MobileNumber)
        // });

        this.otpVerifyForm = this.formBuilder.group({
            mobileNo: [
                '',
                [
                    Validators.required,
                    Validators.minLength(10),
                    Validators.maxLength(10),
                ],
            ],
            otp: ['', Validators.required],
        });

        if (!this.otpService.otpResponse) {
            this.router.navigate(['register']);
        } else {
            this.RegisterResponse();
        }
        // this.otpVerifyForm.controls.mobileNo.setValue(5485125415);
    }


    RegisterResponse() {
        this.otpService.valuefromService((value: any) => value);

        this.registerresponse = this.otpService.otpResponse;
        this.Aadhaar = this.registerresponse.Aadhaar;
        this.MobileNumber = this.registerresponse.Mobile;
        this.EmailID = this.registerresponse.Emailid;
        this.otp = this.registerresponse.OTP;

        if (this.Aadhaar != '') {
          this.otpVerifyForm.controls['mobileNo'].setValue(this.MobileNumber);
        } else {
            this.router.navigate(['']);
        }
    }

    GetOTP() {
        this.submitted = true;
        let jsonin = {
            aadhaar: parseInt(this.Aadhaar),
            emailid: this.EmailID,
            mobileno: parseInt(this.MobileNumber),
        };

        if (this.data.aadhaar > 0) {
            this.otpService.studentsforgotmobile(jsonin).subscribe((response) => {
                // console.log(response);
                if (response.data.OTP != '') {
                    this.otp = response.data.OTP;
                }
                // alert("OTP has been sent to registered Mobile Number!")
                this.globalmessage.Show_message('OTP has been sent to registered Mobile Number!');
            });
        } else {
            this.globalmessage.Show_error('Aadhaar Not Found!');
        }
    }

    ValidateOTP() {
        this.submitted = true;
        this.data = {
            Finyear: this.CollegeCodeConst,
            CollegeCode: this.CollegeCodeConst,
            Aadhaar: parseInt(this.Aadhaar),
            OTP: parseInt(this.otp),
        };
        if (this.otpVerifyForm.invalid) {
            return;
        } else {
            this.otpService.ValidateOTP(this.data).subscribe((response) => {
                // console.log(response);
                if (response.data == true) {
                    this.globalmessage.Show_message('Registration Complete!');
                    this.router.navigate(['login']);
                } else {
                    this.globalmessage.Show_error('Invalid OTP!');
                }
            });
        }
    }
}
