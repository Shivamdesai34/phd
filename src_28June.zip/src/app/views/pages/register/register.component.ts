import {Component} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {OtpService} from '../otp/otp.service';
import Swal from 'sweetalert2';
import * as myGlobals from '../../../globals/global-variable';
import {
  GetOTP_v1_url,
  Getselectedbatchs_url,
  GetOTP,
  StudentRegistration_URL,
  Pg_batchs_URL, registertionbatchs
} from "../../../globals/global-api";
import {CommonService} from "../../../globals/common.service";
import {GlobalMessage} from "../../../globals/global.message";
import {encryptUsingAES256} from "../../../globals/encryptdata";
import {SessionService} from "../../../globals/sessionstorage";
import {Ipg_batchs} from "../../../models/request";

@Component({
    selector: 'app-register',
    templateUrl: 'register.component.html',
    styleUrls: ['./register.component.scss'],
})
export class RegisterComponent {
    // @HostBinding('class') cAppClass = 'c-app flex-row align-items-center';
    Registrationlabel!: string;
    UserType: any;
    registerForm!: FormGroup;
    submitted = false;
    data: any;
    res: any;
    BatchNames!: Ipg_batchs[];
    Selected_batchname!: Ipg_batchs;

    selectedugpg = '';

  studentgettype!: any;

    // @Input() public OTPGetValue;
    // public OTPSendValue;

    get f() {
        return this.registerForm.controls;
    }


    constructor(
        private router: Router,private globalMessage: GlobalMessage,
        private formBuilder: FormBuilder,private sessionservice: SessionService,
        private otpService: OtpService,private globalmessage: GlobalMessage,
        private commanService: CommonService,
    ) {
      this.studentgettype = this.sessionservice.GetData('studenttype')!
        this.UserType = sessionStorage.getItem('UserType');
        if (this.UserType == myGlobals.Global_OUTSIDE) {
            this.Registrationlabel = 'Outside';
        }
        if (this.UserType == myGlobals.Global_ATKT) {
            this.Registrationlabel = 'Atkt';
        }
    }

    ngOnInit(): void {
        // if (!this.UserType) {
        //     this.router.navigate(['']);
        //     // this.openYesNoDialog("Please Click Register button!")
        //     Swal.fire({
        //         title: 'Message!',
        //         text: 'Please Click Register button!',
        //         icon: 'info',
        //         confirmButtonText: 'OK',
        //     }); //alert
        // } else {
            this.registerForm = this.formBuilder.group({
                ugpg: ['', [Validators.required]],
                userbatch: ['', Validators.required],
                aadharNo: [
                    '',
                    [
                        Validators.required,
                        Validators.minLength(12),
                        Validators.maxLength(12),
                    ],
                ],
                email: ['', [Validators.required, Validators.email]],
                mobileNo: [
                    '',
                    [
                        Validators.required,
                        Validators.minLength(10),
                        Validators.maxLength(10),
                    ],
                ],
                linguistic: ['', Validators.required],
                inhouse: ['', Validators.required],
                password: [
                    '',
                    [
                        Validators.required,
                        Validators.pattern(
                            /^(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=\D*\d).{6,10}$/
                        ),
                    ],
                ],
            });

    }

    Show_streambatchs() {
      let sOutsideUrl = myGlobals.Domainname

      let jsoninbatch = {
        Boardlevel: this.selectedugpg,
        Webportal: 'https://admission.rjcollege.edu.in:7006/v1/Students/phd',
        Firstyear: 0
        };

      let jsonin = {
        Input: encryptUsingAES256(jsoninbatch)
      };

        this.commanService.Post_json(registertionbatchs,jsonin).subscribe((response) => {
            if (response!=null){
                this.BatchNames = response.data;
            }
        });
    }

    onUgPg_Selected(value: string): void {
        this.selectedugpg = value;
        if (this.selectedugpg != '') {
            this.Show_streambatchs();
        }
    }

    on_Selectbtch() {
        // this.Get_singlebatch();
      if (this.Selected_batchname.Admissionyear == 0) {
        this.globalMessage.Show_error('Finyear not configured.Please contact admin.')
        this.router.navigate(['/login'])
      }

      if (this.studentgettype == "ATKT" && this.Selected_batchname.Admissionstarted == 0) {
        this.globalMessage.Show_error(this.Selected_batchname.Atkt_message)
        this.router.navigate(['/login'])
      }

      if (this.studentgettype == "OUTSIDE" && this.Selected_batchname.Outside_admission == 0) {
        this.globalMessage.Show_error(this.Selected_batchname.Outside_message)
        this.router.navigate(['/login'])
      }
    }

    onRegister() {
        this.submitted = true;
        let jsonin = {
            Aadhaar: parseInt(this.registerForm.controls['aadharNo'].value),
            EmailID: this.registerForm.controls['email'].value,
            MobileNumber: parseInt(this.registerForm.controls['mobileNo'].value),
            Inhouse: this.registerForm.controls['inhouse'].value,
            Hindilinguistic: this.registerForm.controls['linguistic'].value,
            StudentPassword: this.registerForm.controls['password'].value,
            studenttype: this.studentgettype,
            finyear: myGlobals.Global_CurrentFinYear,
            college_code: myGlobals.Golbal_CollegeCode,
            Coursetype: this.selectedugpg,
            Batch_code: this.Selected_batchname.Batch_code,
        };

        console.log('kkk',jsonin)

        if (this.registerForm.invalid) {
            return;
        }


        // debugger;
        if (jsonin.Aadhaar > 99999999999) {
            this.commanService
                .Post_json(StudentRegistration_URL,jsonin)
                .subscribe((response) => {
                    this.res = response.data;
                    if (this.res == true) {
                        this.GetOTP();
                    } else {
                        this.globalmessage.Show_error(response.exception);
                    }
                });
        } else {
            // this.submitted = false
            this.globalmessage.Show_message('Enter Valid Aadhaar!');
        }
    }


    GetOTP() {
        let jsonin = {
            aadhaar: parseInt(this.registerForm.controls['aadharNo'].value),
            emailid: this.registerForm.controls['email'].value,
            mobile: parseInt(this.registerForm.controls['mobileNo'].value),
        };

        this.commanService.Post_json(GetOTP,jsonin).subscribe((response) => {
            if (response.data.OTP != '') {
                this.otpService.setValue(response.data);

                this.router.navigate(['otp']);
                this.globalmessage.Show_message('OTP has been sent to registered Mobile Number');
                // alert("OTP has been sent to registered Mobile Number")
            } else {
                this.globalmessage.Show_error('OTP not Sent!');
                // alert("OTP not Sent!")
            }
        });
    }

    GetOTP_v1() {
        let jsonin = {
            aadhaar: parseInt(this.registerForm.controls['aadharNo'].value),
            emailid: this.registerForm.controls['email'].value,
            mobile: parseInt(this.registerForm.controls['mobileNo'].value),
        };

        this.commanService.Post_json(GetOTP_v1_url,jsonin).subscribe((response) => {
            if (response.data.OTP != '') {
                this.otpService.setValue(response.data);

                this.router.navigate(['otp']);

                Swal.fire({
                    title: 'Message!',
                    text: 'OTP has been sent to registered Mobile Number',
                    icon: 'success',
                    confirmButtonText: 'OK',
                });

            } else {
                if (response.data.exception == '') {
                    Swal.fire({
                        title: 'Error!',
                        text: response.data.exception,
                        icon: 'error',
                        confirmButtonText: 'OK',
                    });
                } else {
                    Swal.fire({
                        title: 'Error!',
                        text: 'OTP not Sent!',
                        icon: 'error',
                        confirmButtonText: 'OK',
                    });
                }
            }
        });
    }

    Get_singlebatch() {

        let jsonin = {
            batch_code: this.Selected_batchname.Batch_code,
        };

        this.commanService.Post_json(Getselectedbatchs_url,jsonin).subscribe((response) => {
            if (response.data.Outside_admission == false) {
                this.submitted = false;

                Swal.fire({
                    title: 'Message!',
                    text: response.data.Atkt_message,
                    icon: 'error',
                    confirmButtonText: 'OK',
                });

              this.registerForm.controls['userbatch'].setValue('');
            }
        });
    }

    onReset() {
        this.submitted = false;
        this.registerForm.reset();
    }
}
