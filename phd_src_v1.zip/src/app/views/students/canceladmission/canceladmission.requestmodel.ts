
export interface Icancelled_admission {
  Finyear: number
  college_code: number
  Aadhaar: number
  batch_code: number
}

export interface Ireq_bankmasters{
Aadhaar: number
  Finyear: number
  CollegeCode: number
  }

export interface Ireq_bankmasters{
Finyear: number
  Collegecode: number
  Aadhaar: number
}
