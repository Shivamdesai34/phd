export interface Ireq_Batch{
    Finyear: number
    Collegecode: number
    Aadhaar: number
}

export interface Ireq_show_installment{
    CollegeCode: number
    Finyear: number
    BatchCode: number
    Aadhaar: number
}

export interface Ireq_studentapprovedcourse{
    Finyear: number
    Collegecode: number
    Aadhaar: number
}
