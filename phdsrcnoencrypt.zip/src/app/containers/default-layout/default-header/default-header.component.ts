import {Component, Input, OnInit} from '@angular/core';

import { HeaderComponent } from '@coreui/angular-pro';
import {Router} from "@angular/router";
import * as myGlobals from "../../../globals/global-variable";
import {CommonService} from "../../../globals/common.service";
import {DomSanitizer} from "@angular/platform-browser";

@Component({
  selector: 'app-default-header',
  templateUrl: './default-header.component.html'
})
export class DefaultHeaderComponent extends HeaderComponent implements OnInit {

  MyImage: any;
  constructor(private router: Router,
  private commonService: CommonService,
  private sanitizer: DomSanitizer) {

    super();
  }

  ngOnInit() {
    if (!this.TokenSession) {
      this.router.navigate(['/login']);
    }
    this.getImage();
  }

  Finyear = parseInt(sessionStorage.getItem('Finyear')!);

  AadharSession = parseInt(sessionStorage.getItem('Aadhaar')!);
  TokenSession = sessionStorage.getItem('Token');

  @Input() sidebarId: string = 'sidebar1';
  logoutlogin(){
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }
  getImage() {
    let jsonin = {
      Aadhaar: this.AadharSession,
      Collegecode: myGlobals.Golbal_CollegeCode,
      Finyear: this.Finyear,
    };
    this.commonService.StudentImageHeader(jsonin).subscribe((response) => {
      if (response == null) {
        return;
      }

      if (response) {
        // console.log("ddddd",response)
        this.MyImage = this.sanitizer.bypassSecurityTrustResourceUrl(`data:image/png;base64, ${response}`);

      }
    });
  }
}
