import {Injectable} from '@angular/core';

@Injectable()
export class AuthService{

    constructor() { }

    getAuthToken():string {
      const userToken = sessionStorage.getItem('Token');
      return userToken !== null ? userToken : ''
    }
}
