export interface Singlebatch {
    batch_code: number;
}

export interface Validatelogin {
    aadhaar: number
    user_pwd: string
}

export interface IBatchs {
    Batch_Code: number
    Batch_Name: string
    Batch_Short: string
    Course_Code: number
    Course_Name: string
    BatchLevel: number
    BatchLevelGroup: string
    FormAmount: number
    Merchant: string
    Merchant_AccountID: string
    Next_Batch: number
    Active: boolean
}

export interface iBatchemail {
    Batch_code: number
    Cc_email: string
    Bcc_email: string
    Replay_email: string
    Email_body: string
    Email_subjects: string
}

export interface IYear {
    "Finyear": number,
    "FinyearName": string,
    "Fromdate": string,
    "Todate": string,
    "Lockfinyear": null
}
export interface ICode{
    CollegeCode: number,
    Name: string,
    Add1: string,
    Add2: string,
    Add3: string,
    Website: string,
    Logopath: null
}

