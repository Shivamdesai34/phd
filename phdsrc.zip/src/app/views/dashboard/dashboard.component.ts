import {Component, OnInit} from '@angular/core';
import {PlatformLocation} from '@angular/common';
import {HttpClient} from '@angular/common/http';
import Swal from 'sweetalert2';
import {Router} from '@angular/router';
import {Subscription} from 'rxjs';
import {DeviceDetectorService, DeviceInfo} from 'ngx-device-detector';
import {GlobalService} from '../../globals/global.service';
import {CommanService} from '../../services/comman.service';
import {Fees_Receiptmaster, Profilesubmited} from '../../output/outputmodel';
import * as myGlobals from '../../globals/global-variable';
import {GlobalMessage} from "../../globals/global.message";

export let browserRefresh = false;


@Component({
    templateUrl: 'dashboard.component.html',
    styleUrls: ['dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
    subscription!: Subscription;
    FinyearSession: number = 0;
    TokenSession: string = '';
    AadharSession: number = 0;
    BatchCodes: number = 0;
    StudentType: string = '';
    Formfeesbatchcode: number = 0;

    data: any;
    MyProfile: any;
    MyFullname: any;
    MyAadhaar: any;
    MyEmail: any;
    MyMobile: any;
    MyBatch: any;
    MyDOB: any;
    MyCountry: any;
    MyGender: any;
    MyMother_tongue: any;
    MyMarital_status: any;
    MyCreatedate: any;
    finyear: any;
    collegecode: any;
    result: any;
    ResourceBool: boolean = false;
    LastBatchCode: any;
    Nextbatchcode: any;
    res: any;
    Batch_code: any;

    BatchData: any = [];
    Editeddate: any;

    deviceInfo!: DeviceInfo;
    nReload: number = 0;

    studentminbatch!: Fees_Receiptmaster;
    profilesubmited!: Profilesubmited;

    constructor(
        private http: HttpClient,
        private platformLocation: PlatformLocation,
        private router: Router,
        private globalmessage: GlobalMessage,
        private deviceDetectorService: DeviceDetectorService,
        private globalService: GlobalService,
        private commanService: CommanService
    ) {
        /*
        this.subscription = router.events.subscribe((event) => {
          if (event instanceof NavigationStart) {

            browserRefresh = !router.navigated;
            if (browserRefresh) {
              window.location.reload();
            }
          }
        });
        */
        //window.location.reload();
        this.TokenSession = sessionStorage.getItem('Token')!;
        this.AadharSession = parseInt(sessionStorage.getItem('Aadhaar')!);
        this.FinyearSession = parseInt(sessionStorage.getItem('Finyear')!);
        this.BatchCodes = parseInt(sessionStorage.getItem('BatchCode')!);
        this.StudentType = sessionStorage.getItem('StudentType')!;

    }

    ngOnInit() {
        if (!this.TokenSession) {
            this.router.navigate(['/login']);
        }

        this.router.navigate(['/students/formfees']);

        this.deviceInfo = this.deviceDetectorService.getDeviceInfo();
        let DeviceRefershvalue = sessionStorage.getItem(this.deviceInfo.deviceType);
        if (DeviceRefershvalue == '-1') {
            sessionStorage.setItem(this.deviceInfo.deviceType, '1');
            window.location.reload();
        }
        this.MyStudentProfile();
        this.Phdminbatch();
        this.formfeesreceived();
        this.CheckOutstanding();
    }

    openYesNoDialog(msg: any) {
        this.globalmessage.Show_message('Delete')
    }

    CheckOutstanding(): any {
        let jsonin = {
            finyear: myGlobals.Global_LastFinYear,
            college_code: myGlobals.Golbal_CollegeCode,
            aadhaar: this.AadharSession,
            batch_code: -99,
            studenttype: this.StudentType,
            currentfinyear: myGlobals.Global_CurrentFinYear,
        };
        this.commanService
            .checkoutstanding(jsonin)
            .subscribe((response) => {
                this.res = response;

                if (this.res.data.Outstanding == true) {
                    this.finyear = this.res.data.Finyear;
                    this.Batch_code = this.res.data.Lastyearbatchcode;

                    sessionStorage.setItem('BatchCode', this.Batch_code);
                    sessionStorage.setItem('Finyear', this.finyear);
                    Swal.fire({
                        title: 'Message!',
                        text: 'Please pay your last year pending fees!',
                        icon: 'success',
                        confirmButtonText: 'OK',
                    });
                    this.router.navigate(['/students/fees']);
                }
                if (this.res.data.Outstanding == false) {
                    this.finyear = this.res.data.Finyear;
                    this.Batch_code = this.res.data.Batch_code;
                    sessionStorage.setItem('BatchCode', this.Batch_code);
                    sessionStorage.setItem('Finyear', this.finyear);
                }
            });
    }

    ProfileResources() {
        // debugger;
        this.commanService.ProfileResources().subscribe((response) => {
            if (response.data != null) {
                this.ResourceBool = true;
            } else {
                Swal.fire({
                    title: 'Error!',
                    text: 'Network Error , Please Refresh!',
                    icon: 'error',
                    confirmButtonText: 'OK',
                });

            }
        });
    }

    StudentProfileStatus() {
        let jsonin = {
            Finyear: myGlobals.Global_CurrentFinYear,
            Collegecode: myGlobals.Golbal_CollegeCode,
            Aadhaar: this.AadharSession,
            studenttype: this.StudentType,
            webportname: myGlobals.Global_Webportname,
        };
        if (!this.TokenSession) {
            this.commanService
                .StudentProfileStatus(jsonin)
                .subscribe((response) => {
                    this.Batch_code = response.data.Profile.Batch_code;
                    if (response.data.Profile.Aadhaar == 0) {
                        Swal.fire({
                            title: 'Error!',
                            text: 'Pending Personal Details',
                            icon: 'error',
                            confirmButtonText: 'OK',
                        });
                        this.router.navigate(['/students/fillprofile']);
                    } else if (response.data.Education == false) {
                        Swal.fire({
                            title: 'Error!',
                            text: 'Pending Education Details',
                            icon: 'error',
                            confirmButtonText: 'OK',
                        });
                        this.router.navigate(['/students/fillprofile']);
                    } else if (response.data.Reservation.Aadhaar == 0) {
                        Swal.fire({
                            title: 'Error!',
                            text: 'Pending Reservation Details',
                            icon: 'error',
                            confirmButtonText: 'OK',
                        });
                        this.router.navigate(['/students/fillprofile']);
                    }
                });
        }
    }

    formfeesreceived() {
        let jsonin = {
            Finyear: myGlobals.Global_CurrentFinYear,
            Collegecode: myGlobals.Golbal_CollegeCode,
            Aadhaar: this.AadharSession,
        };
        this.commanService.formfeesreceived(jsonin).subscribe((response) => {
            if (response != null) {
                this.Formfeesbatchcode = response.data.Batch_code;

                if (this.Formfeesbatchcode <= 0) {
                    this.router.navigate(['students/fillprofile'], {queryParams: {page: 'FORM'}});
                } else {
                    //this.isProfileSubmited();
                }
            }

        });
    }

    isProfileSubmited() {
        debugger;

        if (this.studentminbatch == null) {
            return;
        }
        let jsonin = {
            Finyear: myGlobals.Global_LastFinYear,
            Collegecode: myGlobals.Golbal_CollegeCode,
            Aadhaar: this.AadharSession,
            BatchCode: this.studentminbatch.Batch_code,//this.Formfeesbatchcode,
        };
        this.commanService
            .Get_ProfileSubmited(jsonin)
            .subscribe((response) => {
                if (response != null) {
                    this.profilesubmited = response.data;
                    if (this.profilesubmited.Profilesubmited == true) {
                        sessionStorage.setItem('BatchCode', this.studentminbatch.Batch_code.toString());
                    } else {
                        this.router.navigate(['students/fillprofile'], {
                            queryParams: {
                                page: 'PROFILE',
                                batch: this.Formfeesbatchcode
                            }
                        });
                    }
                } else {
                    Swal.fire({
                        title: 'Message!',
                        text: response,
                        icon: 'error',
                        confirmButtonText: 'OK',
                    }); //alert
                }
            });
    }

    Phdminbatch() {
        let jsonin = {
            Finyear: myGlobals.Global_LastFinYear,
            Collegecode: myGlobals.Golbal_CollegeCode,
            Aadhaar: this.AadharSession,
        };
        this.commanService.Phdminbatch(jsonin).subscribe((response) => {
            if (response != null) {
                this.studentminbatch = response.data;

                this.isProfileSubmited();
            }
        });
    }

    MyStudentProfile() {

        let jsonin = {
            Collegecode: myGlobals.Golbal_CollegeCode,
            Finyear: this.FinyearSession,
            Aadhaar: this.AadharSession,
        };
        this.commanService.GetStudentProfile(jsonin).subscribe((response) => {
            if (response != null) {
                if (response.data.Admissionbatchs != null) {
                    this.BatchData = response.data.Admissionbatchs;
                }

                this.MyProfile = response.data;
                this.MyFullname = this.MyProfile.FullName;
                this.MyAadhaar = this.MyProfile.Aadhaar;
                this.MyMobile = this.MyProfile.ParentsMobile;
                this.MyBatch = this.MyProfile.Batch_Name;
                this.LastBatchCode = this.MyProfile.Batch_code;
                this.Nextbatchcode = this.MyProfile.Nextbatchcode;
                this.MyDOB = this.MyProfile.DOB;
                this.MyCountry = this.MyProfile.Country;
                this.MyGender = this.MyProfile.Gender;
                this.MyMother_tongue = this.MyProfile.MotherTongue;
                this.MyMarital_status = this.MyProfile.Marital_Status;
                this.MyCreatedate = this.MyProfile.Createddate;
                this.Editeddate = this.MyProfile.Editeddate;
            }
        });


    }
}
