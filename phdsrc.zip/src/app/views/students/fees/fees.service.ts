import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpHeaders,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import Swal from 'sweetalert2';
import {
  StudentApprovedCourses,
  studentactivefinyear,
  StudentBatch,
  BatchSubjects,
  BillDeskcheckSum,
  CheckAdmission_URL,
  CheckSubjectGroupQuota,
  IU_receipt,
  StudentFeesInstallment,
  StudentProfileStatus_url,
  InstallmentValidation,
  StudentSubjectGroup,
  BillDeskcheckSumQuery,
  checkoutstanding,
  FormFeesPaid_URL,
} from '../../../globals/global-api';

@Injectable({
  providedIn: 'root',
})
export class FeesService implements HttpInterceptor {
  constructor(private http: HttpClient) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next
      .handle(req)
      .pipe(catchError((error) => this.handleError(error)));
  }

  // Http Options
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Token ' + sessionStorage.getItem('Token'),
    }),
  };

  // HttpClient API post() method => Create employee
  CheckAdmission(data: any): Observable<any> {
    return this.http
      .post<any>(CheckAdmission_URL, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }
  InstallmentValidation(data: any): Observable<any> {
    return this.http
      .post<any>(InstallmentValidation, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }
  FormFeesPaid(data: any): Observable<any> {
    return this.http
      .post<any>(FormFeesPaid_URL, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  checkoutstanding(data: any): Observable<any> {
    return this.http
      .post<any>(checkoutstanding, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  StudentProfileStatus(data: any): Observable<any> {
    //debugger;
    return this.http
      .post<any>(
        StudentProfileStatus_url,
        JSON.stringify(data),
        this.httpOptions
      )
      .pipe(catchError(this.handleError));
  }
  StudentApprovedCourses(data: any): Observable<any> {
    //debugger;
    return this.http
      .post<any>(StudentApprovedCourses, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  GetBatch(data: any): Observable<any> {
    return this.http
      .post<any>(StudentBatch, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  StudentSubjectGroup(data: any): Observable<any> {
    return this.http
      .post<any>(BatchSubjects, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  StudentFeesInstallments(data: any): Observable<any> {
    return this.http
      .post<any>(StudentFeesInstallment, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  CheckSubjectGroupQuota(data: any): Observable<any> {
    // debugger;
    return this.http
      .post<any>(CheckSubjectGroupQuota, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  BillDeskTransactionPay(data: any) {
    return this.http
      .post<any>(BillDeskcheckSum, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  ReceiptDetails(data: any) {
    return this.http
      .post<any>(IU_receipt, JSON.stringify(data), this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  BillDeskcheckSumQuery(billdeskquerymsg: any): Observable<any> {
    return this.http
      .post<any>(
        BillDeskcheckSumQuery,
        JSON.stringify(billdeskquerymsg),
        this.httpOptions
      )
      .pipe(catchError(this.handleError));
  }

  studentactivefinyear(): Observable<any> {
    return this.http
      .post<any>(studentactivefinyear, '', this.httpOptions)
      .pipe(catchError(this.handleError));
  }

  // Error handling
  handleError(error: HttpErrorResponse): Observable<any> {
    if (error.error !== null) {
      Swal.fire({
        title: 'Message!',
        text: error.error.exception,
        icon: 'error',
        confirmButtonText: 'OK',
      }); //alert
    } else {
      Swal.fire({
        title: 'Error!',
        text: error.status + 'Server Error!',
        icon: 'error',
        confirmButtonText: 'OK',
      }); //alert
    }
    return throwError(error);
  }
}
