import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import {
  BillDeskcheckSum,
  IU_Admission,
  StudentSubjectGroup,
  FormFeesPaid,
  CheckSubjectGroupQuota,
  StudentProfileStatus,
  StudentAppliedCourses,
  BillDeskcheckSumQuery,
  GetAllFirstYearBatchs,
  StudentApprovedCourses,
  PortalOpen,
  PortalOpenv1, Additionalsubjectformfees_URL
} from '../../../globals/global-api';
import Swal from 'sweetalert2';
import { handleError } from '../../pages/login/GlobalHandleerror';

@Injectable({
  providedIn: 'root'
})
export class AdditionalsubjectsService implements HttpInterceptor {

  constructor(private http: HttpClient) { }


  // Http Options With json and Token
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': "Token " + sessionStorage.getItem("Token")
    })
  }


  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError(error => handleError(error))
    );
  }


  StudentProfileStatus(data: any): Observable<any> {
    //debugger;
    return this.http.post<any>(StudentProfileStatus, JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }

  StudentAppliedCourses(data: any): Observable<any> {
    //debugger;
    return this.http.post<any>(StudentAppliedCourses, JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }

  CheckSubjectGroupQuota(data: any): Observable<any> {
    // debugger;
    return this.http.post<any>(CheckSubjectGroupQuota, JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }

  StudentBatch(data: any): Observable<any> {
    return this.http.post<any>(GetAllFirstYearBatchs, JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }

  FormFeesPaidCheck(data: any): Observable<any> {
    return this.http.post<any>(FormFeesPaid, JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }

  Additionalsubjectformfees(data: any): Observable<any> {
    return this.http.post<any>(Additionalsubjectformfees_URL, JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }

  GetModalBatchSubjects(data: any): Observable<any> {
    return this.http.post<any>(StudentSubjectGroup, JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }

  PortalOpen(data: any): Observable<any> {
    return this.http.post<any>(PortalOpenv1, JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }

  AdmissionPayment(data: any): Observable<any> {
    // debugger;
    return this.http.post<any>(IU_Admission, JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }

  BillDeskTransactionPay(billdeskmsg: any): Observable<any> {
    return this.http.post<any>(BillDeskcheckSum, JSON.stringify(billdeskmsg), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }

  BillDeskcheckSumQuery(billdeskquerymsg: any): Observable<any> {
    return this.http.post<any>(BillDeskcheckSumQuery, JSON.stringify(billdeskquerymsg), this.httpOptions)
      .pipe(
        retry(3),
        catchError(handleError)
      )
  }
}

