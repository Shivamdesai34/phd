import { Outputmodel } from './outputmodel';

describe('Outputmodel', () => {
  it('should create an instance', () => {
    expect(new Outputmodel()).toBeTruthy();
  });
});
